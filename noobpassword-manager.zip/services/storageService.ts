
import { PasswordEntry } from '../types';

const MASTER_KEY = 'noob_master_password';
const ENTRIES_KEY = 'noob_vault_entries';

// Simple "noob" security: we just store in localStorage for this demo.
// In a real production app, you would use CryptoJS or SubtleCrypto with the Master Password.
export const storageService = {
  getMasterHash: (): string | null => {
    return localStorage.getItem(MASTER_KEY);
  },

  saveMasterHash: (password: string): void => {
    localStorage.setItem(MASTER_KEY, password);
  },

  getEntries: (masterPassword: string): PasswordEntry[] => {
    const data = localStorage.getItem(ENTRIES_KEY);
    if (!data) return [];
    try {
      // In a real app, decrypt data here using masterPassword
      return JSON.parse(data);
    } catch (e) {
      console.error("Failed to parse vault data", e);
      return [];
    }
  },

  saveEntries: (entries: PasswordEntry[]): void => {
    // In a real app, encrypt entries here
    localStorage.setItem(ENTRIES_KEY, JSON.stringify(entries));
  }
};
