
export enum Category {
  PERSONAL = 'Personal',
  WORK = 'Work',
  SOCIAL = 'Social',
  FINANCE = 'Finance',
  OTHER = 'Other'
}

export interface PasswordEntry {
  id: string;
  title: string;
  username: string;
  password: string;
  url: string;
  category: Category;
  notes: string;
  lastModified: number;
}

export interface VaultState {
  entries: PasswordEntry[];
  masterHash: string | null;
  isUnlocked: boolean;
}
