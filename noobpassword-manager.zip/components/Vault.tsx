
import React, { useState } from 'react';
import { PasswordEntry, Category } from '../types';
import PasswordCard from './PasswordCard';
import PasswordForm from './PasswordForm';
import Generator from './Generator';
import { storageService } from '../services/storageService';

interface VaultProps {
  entries: PasswordEntry[];
  onLogout: () => void;
  onUpdate: (entries: PasswordEntry[]) => void;
}

const Vault: React.FC<VaultProps> = ({ entries, onLogout, onUpdate }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState<Category | 'All'>('All');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<PasswordEntry | undefined>(undefined);
  const [isGeneratorOpen, setIsGeneratorOpen] = useState(false);

  const filteredEntries = entries.filter(entry => {
    const matchesSearch = entry.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          entry.username.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === 'All' || entry.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  const handleSaveEntry = (newEntry: PasswordEntry) => {
    let updatedEntries;
    if (editingEntry) {
      updatedEntries = entries.map(e => e.id === newEntry.id ? newEntry : e);
    } else {
      updatedEntries = [newEntry, ...entries];
    }
    onUpdate(updatedEntries);
    storageService.saveEntries(updatedEntries);
    setIsFormOpen(false);
    setEditingEntry(undefined);
  };

  const handleDeleteEntry = (id: string) => {
    if (window.confirm('Are you sure you want to delete this password?')) {
      const updatedEntries = entries.filter(e => e.id !== id);
      onUpdate(updatedEntries);
      storageService.saveEntries(updatedEntries);
    }
  };

  const handleEdit = (entry: PasswordEntry) => {
    setEditingEntry(entry);
    setIsFormOpen(true);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 pb-32">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">My Secure Vault</h1>
          <p className="text-slate-500">Managing {entries.length} secure passwords</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => setIsGeneratorOpen(true)}
            className="flex items-center gap-2 bg-slate-200 hover:bg-slate-300 px-4 py-2 rounded-lg font-medium transition-colors"
          >
            <i className="fas fa-key text-slate-600"></i>
            Generator
          </button>
          <button 
            onClick={onLogout}
            className="flex items-center gap-2 bg-red-100 hover:bg-red-200 text-red-600 px-4 py-2 rounded-lg font-medium transition-colors"
          >
            <i className="fas fa-sign-out-alt"></i>
            Lock Vault
          </button>
        </div>
      </div>

      {/* Controls */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 mb-8">
        <div className="md:col-span-8 relative">
          <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
          <input
            type="text"
            placeholder="Search passwords or usernames..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none shadow-sm transition-all"
          />
        </div>
        <div className="md:col-span-4">
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value as any)}
            className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none shadow-sm appearance-none"
          >
            <option value="All">All Categories</option>
            {Object.values(Category).map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Password List */}
      {filteredEntries.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEntries.map(entry => (
            <PasswordCard 
              key={entry.id} 
              entry={entry} 
              onDelete={handleDeleteEntry}
              onEdit={handleEdit}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-white rounded-2xl border-2 border-dashed border-slate-200">
          <div className="text-slate-300 text-6xl mb-4">
            <i className="fas fa-folder-open"></i>
          </div>
          <h3 className="text-xl font-semibold text-slate-600">No passwords found</h3>
          <p className="text-slate-400 max-w-xs mx-auto mt-2">
            Start by adding a new password using the button below.
          </p>
        </div>
      )}

      {/* Floating Action Button */}
      <button
        onClick={() => { setEditingEntry(undefined); setIsFormOpen(true); }}
        className="fixed bottom-8 right-8 w-16 h-16 bg-blue-600 text-white rounded-full shadow-2xl flex items-center justify-center hover:bg-blue-700 transition-all hover:scale-110 active:scale-95 z-40"
      >
        <i className="fas fa-plus text-2xl"></i>
      </button>

      {/* Modal Overlays */}
      {isFormOpen && (
        <PasswordForm 
          onClose={() => { setIsFormOpen(false); setEditingEntry(undefined); }} 
          onSave={handleSaveEntry}
          initialData={editingEntry}
        />
      )}

      {isGeneratorOpen && (
        <Generator onClose={() => setIsGeneratorOpen(false)} />
      )}
    </div>
  );
};

export default Vault;
