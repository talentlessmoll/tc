
import React, { useState } from 'react';

interface GeneratorProps {
  onClose: () => void;
}

const Generator: React.FC<GeneratorProps> = ({ onClose }) => {
  const [length, setLength] = useState(16);
  const [useUppercase, setUseUppercase] = useState(true);
  const [useNumbers, setUseNumbers] = useState(true);
  const [useSymbols, setUseSymbols] = useState(true);
  const [password, setPassword] = useState('');
  const [copied, setCopied] = useState(false);

  const generatePassword = () => {
    const lowercase = 'abcdefghijklmnopqrstuvwxyz';
    const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const numbers = '0123456789';
    const symbols = '!@#$%^&*()_+~`|}{[]:;?><,./-=';
    
    let chars = lowercase;
    if (useUppercase) chars += uppercase;
    if (useNumbers) chars += numbers;
    if (useSymbols) chars += symbols;
    
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setPassword(result);
    setCopied(false);
  };

  const copyToClipboard = () => {
    if (!password) return;
    navigator.clipboard.writeText(password);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Initial generation
  React.useEffect(() => {
    generatePassword();
  }, []);

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center px-4">
      <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-300">
        <div className="bg-slate-800 px-6 py-4 flex justify-between items-center text-white">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <i className="fas fa-magic text-yellow-400"></i>
            Password Generator
          </h2>
          <button onClick={onClose} className="hover:bg-slate-700 w-8 h-8 rounded-full flex items-center justify-center">
            <i className="fas fa-times"></i>
          </button>
        </div>

        <div className="p-8">
          <div className="mb-8">
            <div className="relative group">
              <input
                readOnly
                value={password}
                className="w-full bg-slate-50 border-2 border-slate-100 px-4 py-4 rounded-xl text-center text-xl font-mono text-blue-600 font-bold tracking-wider mb-2"
              />
              <button 
                onClick={generatePassword}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-blue-500 p-2"
                title="Refresh"
              >
                <i className="fas fa-sync-alt"></i>
              </button>
            </div>
            <button
              onClick={copyToClipboard}
              className={`w-full py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2 ${
                copied ? 'bg-green-100 text-green-600' : 'bg-blue-600 text-white hover:bg-blue-700'
              }`}
            >
              <i className={copied ? 'fas fa-check' : 'fas fa-copy'}></i>
              {copied ? 'Copied to Clipboard' : 'Copy Password'}
            </button>
          </div>

          <div className="space-y-6">
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="text-sm font-bold text-slate-500 uppercase">Length: {length}</label>
              </div>
              <input
                type="range"
                min="8"
                max="64"
                value={length}
                onChange={(e) => setLength(parseInt(e.target.value))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
            </div>

            <div className="grid grid-cols-1 gap-3">
              <label className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl cursor-pointer hover:bg-slate-100 transition-colors">
                <input
                  type="checkbox"
                  checked={useUppercase}
                  onChange={(e) => setUseUppercase(e.target.checked)}
                  className="w-5 h-5 rounded text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm font-semibold text-slate-700 uppercase">Include Uppercase (A-Z)</span>
              </label>
              <label className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl cursor-pointer hover:bg-slate-100 transition-colors">
                <input
                  type="checkbox"
                  checked={useNumbers}
                  onChange={(e) => setUseNumbers(e.target.checked)}
                  className="w-5 h-5 rounded text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm font-semibold text-slate-700 uppercase">Include Numbers (0-9)</span>
              </label>
              <label className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl cursor-pointer hover:bg-slate-100 transition-colors">
                <input
                  type="checkbox"
                  checked={useSymbols}
                  onChange={(e) => setUseSymbols(e.target.checked)}
                  className="w-5 h-5 rounded text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm font-semibold text-slate-700 uppercase">Include Symbols (!@#$)</span>
              </label>
            </div>
          </div>
          
          <div className="mt-8">
            <button
              onClick={generatePassword}
              className="w-full py-3 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-xl transition-colors"
            >
              Generate Again
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Generator;
