
import React, { useState } from 'react';

interface LoginProps {
  hasMasterPassword: boolean;
  onUnlock: (password: string) => void;
  onSetMaster: (password: string) => void;
}

const Login: React.FC<LoginProps> = ({ hasMasterPassword, onUnlock, onSetMaster }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 4) {
      setError('Password must be at least 4 characters long.');
      return;
    }

    if (hasMasterPassword) {
      const saved = localStorage.getItem('noob_master_password');
      if (password === saved) {
        onUnlock(password);
      } else {
        setError('Incorrect master password.');
      }
    } else {
      onSetMaster(password);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-blue-600 to-indigo-800 px-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl p-8">
        <div className="text-center mb-8">
          <div className="bg-blue-100 text-blue-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-vault text-3xl"></i>
          </div>
          <h1 className="text-2xl font-bold text-gray-800">
            {hasMasterPassword ? 'Unlock Vault' : 'Welcome, Noob!'}
          </h1>
          <p className="text-gray-500 mt-2">
            {hasMasterPassword 
              ? 'Enter your master password to access your keys.' 
              : 'Let\'s set up your first master password. This is the only password you need to remember.'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Master Password
            </label>
            <div className="relative">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete={hasMasterPassword ? "current-password" : "new-password"}
                className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all outline-none"
                placeholder="Enter password..."
                required
              />
              <div className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400">
                <i className="fas fa-lock"></i>
              </div>
            </div>
          </div>

          {error && (
            <div className="bg-red-50 text-red-600 px-4 py-3 rounded-lg text-sm flex items-center gap-2">
              <i className="fas fa-circle-exclamation"></i>
              {error}
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl shadow-lg shadow-blue-200 transition-all transform active:scale-[0.98]"
          >
            {hasMasterPassword ? 'Unlock Now' : 'Create Vault'}
          </button>
        </form>

        <div className="mt-8 pt-8 border-t border-gray-100 text-center">
          <p className="text-xs text-gray-400 italic">
            This manager stores your data locally in your browser. <br/>
            No cloud. No AI. Just you and your storage.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
