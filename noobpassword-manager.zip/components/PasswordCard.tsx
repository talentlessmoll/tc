
import React, { useState } from 'react';
import { PasswordEntry, Category } from '../types';

interface PasswordCardProps {
  entry: PasswordEntry;
  onDelete: (id: string) => void;
  onEdit: (entry: PasswordEntry) => void;
}

const PasswordCard: React.FC<PasswordCardProps> = ({ entry, onDelete, onEdit }) => {
  const [showPassword, setShowPassword] = useState(false);
  const [copied, setCopied] = useState<'user' | 'pass' | null>(null);

  const copyToClipboard = (text: string, type: 'user' | 'pass') => {
    navigator.clipboard.writeText(text);
    setCopied(type);
    setTimeout(() => setCopied(null), 2000);
  };

  const getCategoryColor = (cat: Category) => {
    switch (cat) {
      case Category.PERSONAL: return 'bg-emerald-100 text-emerald-700';
      case Category.WORK: return 'bg-blue-100 text-blue-700';
      case Category.SOCIAL: return 'bg-purple-100 text-purple-700';
      case Category.FINANCE: return 'bg-amber-100 text-amber-700';
      default: return 'bg-slate-100 text-slate-700';
    }
  };

  const maskedPassword = '•'.repeat(Math.min(entry.password.length, 12));

  return (
    <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 hover:shadow-md transition-shadow relative overflow-hidden group">
      {/* Category Badge */}
      <div className={`absolute top-0 right-0 px-3 py-1 rounded-bl-xl text-xs font-bold uppercase tracking-wider ${getCategoryColor(entry.category)}`}>
        {entry.category}
      </div>

      <div className="flex items-center gap-4 mb-5">
        <div className="w-12 h-12 rounded-xl bg-slate-50 flex items-center justify-center text-slate-400 text-xl">
          <i className="fas fa-globe"></i>
        </div>
        <div className="overflow-hidden">
          <h3 className="font-bold text-slate-800 text-lg truncate pr-16">{entry.title}</h3>
          <a 
            href={entry.url.startsWith('http') ? entry.url : `https://${entry.url}`} 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-xs text-blue-500 hover:underline truncate block"
          >
            {entry.url || 'No URL'}
          </a>
        </div>
      </div>

      <div className="space-y-4">
        {/* Username Row */}
        <div>
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Username / Email</label>
          <div className="flex items-center justify-between bg-slate-50 px-3 py-2 rounded-lg border border-slate-100">
            <span className="text-sm font-medium text-slate-600 truncate mr-2">{entry.username}</span>
            <button 
              onClick={() => copyToClipboard(entry.username, 'user')}
              className="text-slate-400 hover:text-blue-500 transition-colors"
              title="Copy Username"
            >
              <i className={copied === 'user' ? 'fas fa-check text-green-500' : 'fas fa-copy'}></i>
            </button>
          </div>
        </div>

        {/* Password Row */}
        <div>
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Password</label>
          <div className="flex items-center justify-between bg-slate-50 px-3 py-2 rounded-lg border border-slate-100">
            <span className="text-sm font-mono text-slate-600 truncate mr-2">
              {showPassword ? entry.password : maskedPassword}
            </span>
            <div className="flex gap-3 text-slate-400">
              <button 
                onClick={() => setShowPassword(!showPassword)}
                className="hover:text-blue-500 transition-colors"
                title={showPassword ? 'Hide Password' : 'Show Password'}
              >
                <i className={showPassword ? 'fas fa-eye-slash' : 'fas fa-eye'}></i>
              </button>
              <button 
                onClick={() => copyToClipboard(entry.password, 'pass')}
                className="hover:text-blue-500 transition-colors"
                title="Copy Password"
              >
                <i className={copied === 'pass' ? 'fas fa-check text-green-500' : 'fas fa-copy'}></i>
              </button>
            </div>
          </div>
        </div>
      </div>

      {entry.notes && (
        <div className="mt-4 pt-4 border-t border-slate-50">
          <p className="text-xs text-slate-400 line-clamp-2 italic">"{entry.notes}"</p>
        </div>
      )}

      {/* Actions Layer */}
      <div className="mt-6 flex gap-2 pt-2">
        <button 
          onClick={() => onEdit(entry)}
          className="flex-1 py-2 text-xs font-bold text-slate-600 bg-slate-100 rounded-lg hover:bg-slate-200 transition-colors"
        >
          Edit
        </button>
        <button 
          onClick={() => onDelete(entry.id)}
          className="px-3 py-2 text-xs font-bold text-red-500 bg-red-50 rounded-lg hover:bg-red-100 transition-colors"
        >
          <i className="fas fa-trash-alt"></i>
        </button>
      </div>
    </div>
  );
};

export default PasswordCard;
