
import React, { useState, useEffect } from 'react';
import Login from './components/Login';
import Vault from './components/Vault';
import { storageService } from './services/storageService';
import { VaultState } from './types';

const App: React.FC = () => {
  const [vault, setVault] = useState<VaultState>({
    entries: [],
    masterHash: null,
    isUnlocked: false,
  });

  const [isLoading, setIsLoading] = useState(true);

  // Load initial state from storage
  useEffect(() => {
    const savedMaster = storageService.getMasterHash();
    if (savedMaster) {
      setVault(prev => ({ ...prev, masterHash: savedMaster }));
    }
    setIsLoading(false);
  }, []);

  const handleUnlock = (password: string) => {
    // In a real app, we'd use pbkdf2 or similar. 
    // Here we use a simple check for demonstration.
    const entries = storageService.getEntries(password);
    setVault(prev => ({
      ...prev,
      entries,
      isUnlocked: true
    }));
  };

  const handleSetMaster = (password: string) => {
    storageService.saveMasterHash(password);
    setVault(prev => ({
      ...prev,
      masterHash: password, // For simplicity, we'll use the plain text as hash in this demo
      isUnlocked: true
    }));
  };

  const handleLogout = () => {
    setVault(prev => ({
      ...prev,
      entries: [],
      isUnlocked: false
    }));
  };

  const updateEntries = (newEntries: any[]) => {
    setVault(prev => ({ ...prev, entries: newEntries }));
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-slate-900">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {!vault.isUnlocked ? (
        <Login 
          hasMasterPassword={!!vault.masterHash} 
          onUnlock={handleUnlock} 
          onSetMaster={handleSetMaster} 
        />
      ) : (
        <Vault 
          entries={vault.entries} 
          onLogout={handleLogout} 
          onUpdate={updateEntries}
        />
      )}
    </div>
  );
};

export default App;
